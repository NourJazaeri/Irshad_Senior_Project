export default function Navbar() {
  return (
    <nav style={{ textAlign: 'center', padding: '20px', background: 'rgba(255,255,255,0.1)', marginBottom: '20px' }}>
      <strong style={{ color: 'white', fontSize: '1.5rem' }}>Company Registration</strong>
    </nav>
  );
}


