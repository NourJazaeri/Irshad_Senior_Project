export default function Footer() {
  return (
    <footer style={{ textAlign: 'center', padding: '20px', color: 'white', opacity: 0.8 }}>
      <small>© 2025 Company Registration System</small>
    </footer>
  );
}


