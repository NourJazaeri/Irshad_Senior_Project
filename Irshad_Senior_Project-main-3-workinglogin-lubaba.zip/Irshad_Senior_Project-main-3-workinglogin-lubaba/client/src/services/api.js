// client/src/services/api.js
const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:5002';

export function getAuthHeaders(contentType = 'application/json') {
  const token = localStorage.getItem('token');
  const headers = {};
  if (contentType) headers['Content-Type'] = contentType;
  headers['Accept'] = 'application/json';
  if (token) headers['Authorization'] = `Bearer ${token}`;
  return headers;
}

export function clearAuth() {
  localStorage.removeItem('token');
}

// Login user: stores token on success
export async function loginUser({ email, password, role }) {
  try {
    console.log("Sending login request to:", `${API_BASE}/api/auth/login`);
    const response = await fetch(`${API_BASE}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify({ role, email, password }),
    });

    console.log("Response status:", response.status);
    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      const message = data?.message || (
        response.status === 400 ? "Email, password and role are required" :
        response.status === 401 ? "Incorrect password" :
        response.status === 403 ? "You are not allowed to log in" :
        response.status === 404 ? "Account not found" :
        response.status === 503 ? "Service temporarily unavailable. Please try again later." :
        "Login failed"
      );
      return { success: false, message };
    }

    console.log("Response data:", data);

    // store token if present
    if (data?.token) {
      localStorage.setItem('token', data.token);
    }

    return data;
  } catch (error) {
    console.error("Error logging in:", error);
    return { success: false, message: "Network error - cannot connect to server" };
  }
}

// Logout and clear local token
export async function logoutUser(sessionId) {
  try {
    console.log("Sending logout request to:", `${API_BASE}/api/auth/logout`);
    const response = await fetch(`${API_BASE}/api/auth/logout`, {
      method: "POST",
      headers: getAuthHeaders(), // includes Authorization if token exists
      body: JSON.stringify({ sessionId }),
    });

    console.log("Logout response status:", response.status);

    if (!response.ok) {
      const text = await response.text().catch(() => "");
      throw new Error(`HTTP error! status: ${response.status}. ${text}`);
    }

    const data = await response.json();
    console.log("Logout response data:", data);

    // clear local storage token always after logout
    clearAuth();

    return data;
  } catch (error) {
    console.error("Error logging out:", error);
    // still clear local token if server failed
    clearAuth();
    return { success: false, message: error.message || "Cannot connect to server during logout." };
  }
}

export default {
  API_BASE,
  loginUser,
  logoutUser,
  getAuthHeaders,
  clearAuth
};
