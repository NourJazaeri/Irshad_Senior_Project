import ActivityLog from './ActivityLog';

export default function Reports() {
  return <ActivityLog />;
}
