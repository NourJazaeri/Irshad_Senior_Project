import PendingCompanyRegistrations from './PendingCompanyRegistrations.jsx';

export default function Registrations() {
  return <PendingCompanyRegistrations />;
}
